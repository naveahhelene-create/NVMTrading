# NVM Trading Website

Free static website designed for GitHub Pages.

## Publish on GitHub Pages
1. Create a GitHub account.
2. Create a repository named `YOURUSERNAME.github.io`.
3. Upload `index.html`, `style.css`, and `logo.png`.
4. Open Settings → Pages.
5. Select "Deploy from a branch", choose `main`, and save.
6. Your site will appear at `https://YOURUSERNAME.github.io`.

Before launch:
- Replace the placeholder enrollment email in `index.html`.
- Replace the sample $49 price with your actual price.
- Add your real course checkout/payment system.
- Review the legal/disclaimer language for your business and jurisdiction.
